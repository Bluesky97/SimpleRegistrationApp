﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class RegisterPage : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        btnLogin.Visible = false;
    }

    protected void btnRegister_Click(object sender, EventArgs e)
    {
        //customer
        Customer c = new Customer()
        {
            CustEmail = tbxEmail.Text,
            FirstName = tbxFName.Text,
            LastName = tbxLName.Text,
            DateOfBirth = Convert.ToDateTime(tbxDOB.Text),
            Gender = tbxGender.Text,
            PhoneNumber = tbxPhone.Text,
        };
        int id = CustomerDB.addCustomer(c);
        lblOutput.Text = id + "Registered Successfully!";

        if(lblOutput.Text == id + "Registered Successfully!")
        {
            tbxEmail.Enabled = false;
            tbxFName.Enabled = false;
            tbxLName.Enabled = false;
            tbxDOB.Enabled = false;
            tbxGender.Enabled = false;
            tbxPhone.Enabled = false;

            btnRegister.Enabled = false;

            btnLogin.Visible = true;
        }
        else
        {
            tbxEmail.Enabled = true;
            tbxFName.Enabled = true;
            tbxLName.Enabled = true;
            tbxDOB.Enabled = true;
            tbxGender.Enabled = true;
            tbxPhone.Enabled = true;

            btnRegister.Enabled = true;
        }
    }

    protected void btnLogin_Click(object sender, EventArgs e)
    {
        Server.Transfer("LoginPage.aspx");
    }
}