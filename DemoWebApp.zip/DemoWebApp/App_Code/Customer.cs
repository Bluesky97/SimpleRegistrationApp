﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
//INFT 3970 - FYP Project
//Start Date : 10th May 2018
//Submission Date : 1st August 2018
//Names     :Andrian Alexander Putra(c3271469)
//          :Zhang Chuhan(c3270145)
//          :Thet Paing Htun(c3271285)
//          :Hay Marn Oo(c3271471)
/// <summary>
/// Summary description for Customer
/// </summary>
public class Customer
{
    //attributes
    public string CustEmail { get; set; }
    public string FirstName { get; set; }
    public string LastName { get; set; }
    public DateTime DateOfBirth { get; set; }
    public string Gender { get; set; }
    public string PhoneNumber { get; set; }

    public override string ToString()
    {
        return CustEmail + " " + FirstName + " " + LastName + " " + DateOfBirth + " " + Gender + " " + PhoneNumber;
    }
}