﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
//INFT 3970 - FYP Project
//Start Date : 10th May 2018
//Submission Date : 1st August 2018
//Names     :Andrian Alexander Putra(c3271469)
//          :Zhang Chuhan(c3270145)
//          :Thet Paing Htun(c3271285)
//          :Hay Marn Oo(c3271471)
/// <summary>
/// Summary description for CustomerDB
/// </summary>
public class CustomerDB
{
    public static string conStr = ConfigurationManager.ConnectionStrings["myConnectionString"].ConnectionString;

    public static List<Customer> getAllCustomers()
    {
        SqlConnection con = new SqlConnection(conStr);
        try
        {
            SqlCommand command = new SqlCommand();
            command.Connection = con;
            command.CommandText = "Select * from Customer";
            con.Open();
            SqlDataReader reader = command.ExecuteReader();
            List<Customer> customers = null;
            if (reader.HasRows)
                customers = new List<Customer>();
            while (reader.Read())
            {
                customers.Add(
                    new Customer()
                    {
                        CustEmail = reader["custEmail"].ToString(),
                        FirstName = reader["firstName"].ToString(),
                        LastName = reader["lastName"].ToString(),
                        DateOfBirth = Convert.ToDateTime(reader["dateOfBirth"]),
                        Gender = reader["gender"].ToString(),
                        PhoneNumber = reader["phoneNumber"].ToString(),
                    });
            }
            reader.Close();
            return customers;
        }
        finally
        {
            con.Close();
        }
    }
    public static int addCustomer(Customer c)
    {
        SqlConnection con = new SqlConnection(conStr);
        try
        {
            SqlCommand command = new SqlCommand();
            command.Connection = con;
            command.CommandText = "insert into Customer (custEmail, firstName, lastName, dateOfBirth, gender, phoneNumber) values (@custEmail, @firstName, @lastName, @dateOfBirth, @gender, @phoneNumber)";
            command.Parameters.AddWithValue("@custEmail", c.CustEmail);
            command.Parameters.AddWithValue("@firstName", c.FirstName);
            command.Parameters.AddWithValue("@lastName", c.LastName);
            command.Parameters.AddWithValue("@dateOfBirth", c.DateOfBirth);
            command.Parameters.AddWithValue("@gender", c.Gender);
            command.Parameters.AddWithValue("@phoneNumber", c.PhoneNumber);
            con.Open();
            return command.ExecuteNonQuery();
        }
        finally
        {
            con.Close();
        }
    }

}